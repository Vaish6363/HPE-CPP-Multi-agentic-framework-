import { NextResponse } from "next/server";

export const config = {
  matcher: "/integrations/:path*",
};

export function middleware(request) {
  const requestHeaders = new Headers(request.headers);
  requestHeaders.set("x-createxyz-project-id", "2b1ba524-6ddd-426a-af9a-cb8fb117b5d2");
  requestHeaders.set("x-createxyz-project-group-id", "f4e6995b-bc10-4f4a-83b2-75b75d199199");


  request.nextUrl.href = `https://www.create.xyz/${request.nextUrl.pathname}`;

  return NextResponse.rewrite(request.nextUrl, {
    request: {
      headers: requestHeaders,
    },
  });
}