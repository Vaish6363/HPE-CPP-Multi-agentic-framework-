"use client";
import React from "react";

function MainComponent() {
  const [messages, setMessages] = useState([]);
  const [inputMessage, setInputMessage] = useState("");
  const [loading, setLoading] = useState(false);
  const [currentAgent, setCurrentAgent] = useState(null);
  const [agentHistory, setAgentHistory] = useState([]);
  const [showWelcome, setShowWelcome] = useState(true);
  const [handoffSuggestion, setHandoffSuggestion] = useState(null);

  const agents = [
    {
      id: "academics",
      title: "Academic Tutor",
      name: "Dr. Sarah",
      icon: "📘",
      description: "Expert in studies, assignments, and learning strategies",
      keywords: [
        "study",
        "homework",
        "assignment",
        "exam",
        "learning",
        "subject",
        "course",
        "grade",
        "test",
        "quiz",
        "research",
        "essay",
        "math",
        "science",
        "history",
        "literature",
      ],
      handoffTriggers: [
        "stress",
        "anxiety",
        "overwhelmed",
        "career",
        "job",
        "future",
        "productivity",
        "time management",
      ],
    },
    {
      id: "career",
      title: "Career Counselor",
      name: "Mike Johnson",
      icon: "💼",
      description: "Specialist in career guidance and professional development",
      keywords: [
        "job",
        "career",
        "interview",
        "resume",
        "professional",
        "internship",
        "skills",
        "networking",
        "salary",
        "promotion",
        "workplace",
      ],
      handoffTriggers: [
        "study",
        "exam",
        "stress",
        "anxiety",
        "balance",
        "productivity",
        "goals",
      ],
    },
    {
      id: "performance",
      title: "Performance Coach",
      name: "Alex Chen",
      icon: "💪",
      description:
        "Expert in productivity, time management, and goal achievement",
      keywords: [
        "productivity",
        "time",
        "management",
        "focus",
        "motivation",
        "habits",
        "goals",
        "procrastination",
        "efficiency",
        "planning",
      ],
      handoffTriggers: [
        "stress",
        "overwhelmed",
        "career",
        "study",
        "exam",
        "mental health",
      ],
    },
    {
      id: "welfare",
      title: "Wellness Counselor",
      name: "Emma Davis",
      icon: "💚",
      description: "Specialist in mental health and well-being support",
      keywords: [
        "stress",
        "anxiety",
        "mental",
        "health",
        "wellness",
        "balance",
        "support",
        "overwhelmed",
        "depression",
        "burnout",
        "self-care",
      ],
      handoffTriggers: [
        "study",
        "career",
        "productivity",
        "goals",
        "exam",
        "work",
      ],
    },
  ];

  const detectBestAgent = (message) => {
    const lowerMessage = message.toLowerCase();
    let bestMatch = null;
    let maxScore = 0;

    for (const agent of agents) {
      const score = agent.keywords.reduce((acc, keyword) => {
        return acc + (lowerMessage.includes(keyword) ? 1 : 0);
      }, 0);

      if (score > maxScore) {
        maxScore = score;
        bestMatch = agent;
      }
    }

    return bestMatch;
  };

  const detectHandoffNeed = (message, currentAgentId) => {
    if (!currentAgentId) return null;

    const lowerMessage = message.toLowerCase();
    const currentAgentData = agents.find((a) => a.id === currentAgentId);

    if (!currentAgentData) return null;

    // Check if message contains triggers for other agents
    for (const trigger of currentAgentData.handoffTriggers) {
      if (lowerMessage.includes(trigger)) {
        const suggestedAgent = detectBestAgent(message);
        if (suggestedAgent && suggestedAgent.id !== currentAgentId) {
          return suggestedAgent;
        }
      }
    }

    return null;
  };

  const getSystemPrompt = (agent, context = {}) => {
    const { previousAgent, handoffReason } = context;

    const basePrompts = {
      academics: `You are Dr. Sarah, an experienced academic tutor. You help students with studies, assignments, and learning strategies. Be encouraging, clear, and educational. ${
        previousAgent
          ? `You're taking over from ${previousAgent} because the conversation shifted to academic matters.`
          : ""
      }`,

      career: `You are Mike Johnson, a career counselor with 15+ years of experience. You provide practical guidance on career paths, job searching, resume building, and professional development. Be motivating and actionable. ${
        previousAgent
          ? `You're taking over from ${previousAgent} because the conversation moved to career-related topics.`
          : ""
      }`,

      performance: `You are Alex Chen, a performance coach specializing in productivity and personal development. You help students improve time management, set goals, and build better habits. Be energetic and solution-focused. ${
        previousAgent
          ? `You're taking over from ${previousAgent} because the student needs help with productivity or performance.`
          : ""
      }`,

      welfare: `You are Emma Davis, a wellness counselor focused on mental health and well-being. You provide empathetic support for stress, anxiety, and overall wellness. Always encourage seeking professional help when needed. Be compassionate and supportive. ${
        previousAgent
          ? `You're taking over from ${previousAgent} because the student expressed stress or wellness concerns.`
          : ""
      }`,
    };

    return (
      basePrompts[agent?.id] ||
      "You are an AI educational assistant helping students. Be helpful, supportive, and encouraging."
    );
  };

  const handleAgentHandoff = (newAgent, reason = "") => {
    const previousAgent = currentAgent
      ? agents.find((a) => a.id === currentAgent.id)?.name
      : null;

    setCurrentAgent(newAgent);
    setAgentHistory((prev) => [
      ...prev,
      { agent: newAgent, timestamp: Date.now(), reason },
    ]);
    setHandoffSuggestion(null);

    const handoffMessage = `Hi! I'm ${newAgent.name}, your ${newAgent.title}. ${
      previousAgent
        ? `${previousAgent} thought I could better help you with this topic.`
        : ""
    } How can I assist you today?`;

    setMessages((prev) => [
      ...prev,
      {
        role: "assistant",
        content: handoffMessage,
        agent: newAgent,
        isHandoff: true,
      },
    ]);
  };

  const sendMessage = async () => {
    if (!inputMessage.trim()) return;

    const userMessage = inputMessage.trim();
    let targetAgent = currentAgent;
    let handoffContext = {};

    // Detect if we need to switch agents
    if (!currentAgent) {
      targetAgent = detectBestAgent(userMessage);
    } else {
      const suggestedHandoff = detectHandoffNeed(userMessage, currentAgent.id);
      if (suggestedHandoff) {
        setHandoffSuggestion(suggestedHandoff);
        // For now, auto-handoff. Could make this optional with user confirmation
        targetAgent = suggestedHandoff;
        handoffContext = {
          previousAgent: currentAgent.name,
          handoffReason: "Topic shift detected",
        };
      }
    }

    // Update current agent if changed
    if (!currentAgent || (targetAgent && targetAgent.id !== currentAgent.id)) {
      setCurrentAgent(targetAgent);
      if (targetAgent) {
        setAgentHistory((prev) => [
          ...prev,
          {
            agent: targetAgent,
            timestamp: Date.now(),
            reason: handoffContext.handoffReason || "Initial assignment",
          },
        ]);
      }
    }

    const newMessages = [...messages, { role: "user", content: userMessage }];
    setMessages(newMessages);
    setInputMessage("");
    setLoading(true);
    setShowWelcome(false);

    try {
      const systemPrompt = getSystemPrompt(targetAgent, handoffContext);
      const chatMessages = [
        { role: "system", content: systemPrompt },
        ...newMessages.slice(-10), // Keep last 10 messages for context
      ];

      const response = await fetch("/integrations/chat-gpt/conversationgpt4", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          messages: chatMessages,
        }),
      });

      if (!response.ok) {
        throw new Error(`API request failed: ${response.status}`);
      }

      const data = await response.json();
      let aiResponse = data.choices[0].message.content;

      // Add agent handoff message if this is a new agent
      if (handoffContext.previousAgent && targetAgent) {
        aiResponse = `*${targetAgent.name} (${targetAgent.title}) joins the conversation*\n\n${aiResponse}`;
      }

      setMessages([
        ...newMessages,
        {
          role: "assistant",
          content: aiResponse,
          agent: targetAgent,
        },
      ]);
    } catch (error) {
      console.error("Error sending message:", error);
      setMessages([
        ...newMessages,
        {
          role: "assistant",
          content: "Sorry, I encountered an error. Please try again.",
          agent: targetAgent,
        },
      ]);
    } finally {
      setLoading(false);
    }
  };

  const selectAgent = (agent) => {
    handleAgentHandoff(agent, "User selection");
    setShowWelcome(false);
  };

  const resetChat = () => {
    setMessages([]);
    setCurrentAgent(null);
    setAgentHistory([]);
    setShowWelcome(true);
    setHandoffSuggestion(null);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 font-inter">
      {/* Header */}
      <div className="bg-white shadow-sm border-b">
        <div className="max-w-4xl mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-gradient-to-r from-blue-500 to-indigo-600 rounded-lg flex items-center justify-center">
                <span className="text-white font-bold text-lg">E</span>
              </div>
              <div>
                <h1 className="text-2xl font-bold text-gray-900">Edutrack</h1>
                <p className="text-sm text-gray-600">
                  AI-Powered Educational Assistant
                </p>
              </div>
            </div>
            <div className="flex items-center space-x-4">
              {currentAgent && (
                <div className="flex items-center space-x-2 bg-blue-50 px-3 py-1 rounded-full">
                  <span className="text-lg">{currentAgent.icon}</span>
                  <span className="text-sm font-medium text-blue-700">
                    {currentAgent.name}
                  </span>
                </div>
              )}
              <button
                onClick={resetChat}
                className="px-4 py-2 text-sm bg-gray-100 hover:bg-gray-200 rounded-lg transition-colors"
              >
                New Chat
              </button>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-4xl mx-auto px-4 py-6">
        {/* Welcome Screen */}
        {showWelcome && (
          <div className="text-center mb-8">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">
              Welcome to Edutrack! 🎓
            </h2>
            <p className="text-lg text-gray-600 mb-8">
              Your team of AI specialists for academic success and personal
              growth
            </p>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
              {agents.map((agent) => (
                <div
                  key={agent.id}
                  onClick={() => selectAgent(agent)}
                  className="bg-white rounded-xl p-6 shadow-md hover:shadow-lg transition-all cursor-pointer border hover:border-blue-300 group"
                >
                  <div className="text-4xl mb-4 group-hover:scale-110 transition-transform">
                    {agent.icon}
                  </div>
                  <h3 className="text-xl font-semibold text-gray-900 mb-1">
                    {agent.name}
                  </h3>
                  <p className="text-sm text-blue-600 font-medium mb-2">
                    {agent.title}
                  </p>
                  <p className="text-gray-600 text-sm">{agent.description}</p>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Current Agent Header */}
        {currentAgent && !showWelcome && (
          <div className="bg-white rounded-lg p-4 mb-6 shadow-sm border">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <span className="text-2xl">{currentAgent.icon}</span>
                <div>
                  <h3 className="font-semibold text-gray-900">
                    {currentAgent.name}
                  </h3>
                  <p className="text-sm text-blue-600">{currentAgent.title}</p>
                  <p className="text-xs text-gray-500">
                    {currentAgent.description}
                  </p>
                </div>
              </div>
              {agentHistory.length > 1 && (
                <div className="text-xs text-gray-500">
                  Agent #{agentHistory.length}
                </div>
              )}
            </div>
          </div>
        )}

        {/* Agent History Trail */}
        {agentHistory.length > 1 && !showWelcome && (
          <div className="bg-gray-50 rounded-lg p-3 mb-6 border">
            <p className="text-xs text-gray-600 mb-2">Conversation Flow:</p>
            <div className="flex items-center space-x-2 overflow-x-auto">
              {agentHistory.map((entry, index) => (
                <div
                  key={index}
                  className="flex items-center space-x-2 flex-shrink-0"
                >
                  <div className="flex items-center space-x-1 bg-white px-2 py-1 rounded text-xs">
                    <span>{entry.agent.icon}</span>
                    <span className="font-medium">{entry.agent.name}</span>
                  </div>
                  {index < agentHistory.length - 1 && (
                    <span className="text-gray-400">→</span>
                  )}
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Chat Messages */}
        {messages.length > 0 && (
          <div className="bg-white rounded-lg shadow-sm border mb-6">
            <div className="p-6 space-y-4 max-h-96 overflow-y-auto">
              {messages.map((message, index) => (
                <div key={index}>
                  {message.isHandoff && (
                    <div className="text-center py-2">
                      <div className="inline-block bg-blue-100 text-blue-800 px-3 py-1 rounded-full text-xs">
                        Agent Switch: {message.agent.name} joined
                      </div>
                    </div>
                  )}
                  <div
                    className={`flex ${
                      message.role === "user" ? "justify-end" : "justify-start"
                    }`}
                  >
                    <div
                      className={`max-w-xs lg:max-w-md px-4 py-2 rounded-lg ${
                        message.role === "user"
                          ? "bg-blue-500 text-white"
                          : "bg-gray-100 text-gray-900"
                      }`}
                    >
                      {message.role === "assistant" && message.agent && (
                        <div className="flex items-center space-x-1 mb-1">
                          <span className="text-xs">{message.agent.icon}</span>
                          <span className="text-xs font-medium opacity-75">
                            {message.agent.name}
                          </span>
                        </div>
                      )}
                      <p className="text-sm whitespace-pre-wrap">
                        {message.content}
                      </p>
                    </div>
                  </div>
                </div>
              ))}
              {loading && (
                <div className="flex justify-start">
                  <div className="bg-gray-100 rounded-lg px-4 py-2">
                    <div className="flex space-x-1">
                      <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce"></div>
                      <div
                        className="w-2 h-2 bg-gray-400 rounded-full animate-bounce"
                        style={{ animationDelay: "0.1s" }}
                      ></div>
                      <div
                        className="w-2 h-2 bg-gray-400 rounded-full animate-bounce"
                        style={{ animationDelay: "0.2s" }}
                      ></div>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>
        )}

        {/* Input Area */}
        {!showWelcome && (
          <div className="bg-white rounded-lg shadow-sm border p-4">
            <div className="flex space-x-4">
              <input
                type="text"
                value={inputMessage}
                onChange={(e) => setInputMessage(e.target.value)}
                onKeyPress={(e) => e.key === "Enter" && sendMessage()}
                placeholder={
                  currentAgent
                    ? `Ask ${currentAgent.name} anything...`
                    : "Type your message here..."
                }
                className="flex-1 px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                disabled={loading}
              />
              <button
                onClick={sendMessage}
                disabled={loading || !inputMessage.trim()}
                className="px-6 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
              >
                Send
              </button>
            </div>
          </div>
        )}

        {/* Quick Start Message */}
        {showWelcome && (
          <div className="text-center">
            <p className="text-gray-600 mb-4">
              Choose a specialist above to get started, or simply start typing
              your question!
            </p>
            <div className="bg-white rounded-lg shadow-sm border p-4">
              <div className="flex space-x-4">
                <input
                  type="text"
                  value={inputMessage}
                  onChange={(e) => setInputMessage(e.target.value)}
                  onKeyPress={(e) => e.key === "Enter" && sendMessage()}
                  placeholder="Ask anything about academics, career, performance, or wellness..."
                  className="flex-1 px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  disabled={loading}
                />
                <button
                  onClick={sendMessage}
                  disabled={loading || !inputMessage.trim()}
                  className="px-6 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
                >
                  Send
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

export default MainComponent;